package com.unicuritiba.ArenaPlanetaria;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/planets")

public class PlanetController {
    private List<Planet> planets = new ArrayList<>();

    @GetMapping
    public String listPlanets(Model model) {
        model.addAttribute("planets", planets);
        return "planetList";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("planet", new Planet());
        return "addPlanet";
    }

    @PostMapping("/add")
    public String addPlanet(@ModelAttribute("planet") Planet planet) {
        planets.add(planet);
        return "redirect:/planets";
    }
}
