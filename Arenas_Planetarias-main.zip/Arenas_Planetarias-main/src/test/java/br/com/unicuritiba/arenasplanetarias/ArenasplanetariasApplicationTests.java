package br.com.unicuritiba.arenasplanetarias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArenasplanetariasApplicationTests {

	@Test
	void contextLoads() {
	}

}
