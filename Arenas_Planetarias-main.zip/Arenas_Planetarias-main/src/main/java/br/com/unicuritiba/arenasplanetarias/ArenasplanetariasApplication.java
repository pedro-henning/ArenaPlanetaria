package br.com.unicuritiba.arenasplanetarias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArenasplanetariasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArenasplanetariasApplication.class, args);
	}

}
